import 'package:flutter/material.dart';

import 'package:Bookmytrainings/Screens/Loading.dart';


void main(){

    runApp(MaterialApp(
        title: "Bookmytrainings",
        home: SplashScreen(),
        debugShowCheckedModeBanner: false,
    ));

}