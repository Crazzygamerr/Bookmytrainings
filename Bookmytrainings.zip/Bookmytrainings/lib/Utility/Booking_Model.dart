
class BookingModel{

    String id;
    String bookingId;
    String title;
    String date1;
    String date2;
    String v1,v2;
    String coordinates;
    double x,y;

    /*BookingModel(this.id, this.booking_id, this.title, this.date1, this.date2, this.v1, this.v2, this.coordinates){
        List<String> temp;
        if(coordinates != null){
            temp = coordinates.split(',');
            x = double.parse(temp[0]);
            y = double.parse(temp[1]);
        }
    }*/

}
