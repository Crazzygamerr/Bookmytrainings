
import 'package:flutter/material.dart';

class BannerModel{

    String id;
    String title;
    String description;
    String comments;
    String date;
    String city;
    String link;
    String color;
    var color1,color2;

    BannerModel(this.id, this.title, this.description, this.comments, this.date, this.city, this.link, this.color){
        switch(color){

            case "0":
            case "orange":
                color1 = Colors.orange;
                color2 = Colors.orangeAccent;
                break;

            case "3":
            case "amber":
                color1 = Colors.amber;
                color2 = Colors.amberAccent;
                break;

            case "1":
            case "red":
                color1 = Colors.red;
                color2 = Colors.pink;
                break;

            case "10":
            case "cyan":
                color1 = Colors.cyan;
                color2 = Colors.cyanAccent;
                break;

            case "8":
            case "lightBlue":
                color1 = Colors.lightBlue;
                color2 = Colors.lightBlueAccent;
                break;

            case "2":
            case "blue":
                color1 = Colors.blueAccent;
                color2 = Colors.lightBlueAccent;
                break;

            case "5":
            case "indigo":
                color1 = Colors.indigo;
                color2 = Colors.indigoAccent;
                break;

            case "4":
            case "purple":
                color1 = Colors.deepPurple;
                color2 = Colors.deepPurpleAccent;
                break;

            case "7":
            case "teal":
                color1 = Colors.teal;
                color2 = Colors.tealAccent;
                break;

            case "9":
            case "lightGreen":
                color1 = Colors.lightGreen;
                color2 = Colors.lightGreenAccent;
                break;

            case "6":
            case "green":
                color1 = Colors.green;
                color2 = Colors.lightGreenAccent;
                break;

        }
    }

}